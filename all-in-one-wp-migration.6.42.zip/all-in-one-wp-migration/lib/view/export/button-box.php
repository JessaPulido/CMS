<a href="https://servmask.com/products/box-extension" target="_blank"><?php _e( 'Box', AI1WM_PLUGIN_NAME ); ?></a>
