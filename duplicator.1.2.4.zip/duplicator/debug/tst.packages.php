<div class="section-hdr">PACKAGE CTRLS</div>

<form>
	<?php 
		$CTRL['Title']   = 'duplicator_package_scan';
		$CTRL['Action']  = 'duplicator_package_scan'; 
		$CTRL['Test']	 = false;
		DUP_DEBUG_TestSetup($CTRL); 
	?>
	<div class="params">
		No Params
	</div>
</form>

